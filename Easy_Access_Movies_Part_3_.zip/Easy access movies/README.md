# Easy Access Movies — Part 3

## About
Easy Access Movies is a beginner-friendly website that helps visitors browse movie posters, view local trailer videos, search titles and select a rating. Part 3 extends the Part 2 website using the same simple HTML, CSS and JavaScript approach.

## Project structure
```text
Easy access movies/
├── index.html
├── enquiry.html
├── contact.html
├── robots.txt
├── sitemap.xml
├── README.md
├── css/
│   └── style.css
├── js/
│   └── script.js
├── documents/
│   ├── CHANGELOG.md
│   └── REFERENCES.md
└── Images/
    ├── movie poster images
    └── trailer videos
```

## Run the website
1. Extract the ZIP file.
2. Open the `Easy access movies` folder in Visual Studio Code.
3. Open `index.html` and choose **Open with Live Server** (if the extension is installed), or open the file in a browser.
4. Use the navigation to open the enquiry and contact forms.

## Part 3 functionality
- Search the movie collection by title.
- Sort movies by title A–Z or Z–A.
- Select a rating from one to five stars and see confirmation.
- Expand the FAQ details.
- Click gallery posters to open a lightbox; close it with the button, by clicking outside, or by pressing Escape.
- Enquiry form collects a name, email, optional phone number, enquiry type, movie/service and details.
- Contact form collects a name, email, message type and message.
- HTML required/type/length/pattern constraints plus JavaScript validation provide user feedback.
- Responsive layouts and keyboard focus indicators support mobile and keyboard users.

## Forms: important limitation
The forms validate the fields and open the visitor's default email application with the information prepared in an email. The forms are configured to address enquiries to `ST10515213@rcconnect.edu.za`. No email is automatically sent by the browser and there is no server-side storage or AJAX endpoint in this static version. A real AJAX submission requires a backend or form service.

## SEO
Each HTML page has a descriptive title and meta description. The site uses meaningful headings, descriptive image alt text, responsive styling, and internal links. `robots.txt` and `sitemap.xml` are starter templates; replace `example.com` with the real deployed domain before publishing. Local files cannot be indexed by search engines until the site is hosted online.

## Deployment
The website can be deployed to GitHub Pages or Netlify. After deployment, update the domain in `robots.txt` and `sitemap.xml`, check every link and image, and submit the sitemap to Google Search Console if desired.

## Changelog and references
See `documents/CHANGELOG.md` for the Part 3 changes and `documents/REFERENCES.md` for documentation used.
