# References

The following documentation informed the HTML, CSS, JavaScript, accessibility and SEO techniques used in Part 3. Accessed 2 November 2026.

1. MDN Web Docs. “HTML forms.” https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms
2. MDN Web Docs. “Client-side form validation.” https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation
3. MDN Web Docs. “Document Object Model (DOM).” https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model
4. Google Search Central. “SEO Starter Guide.” https://developers.google.com/search/docs/fundamentals/seo-starter-guide
5. Google Search Central. “Build and submit a sitemap.” https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap
6. Google Search Central. “Introduction to robots.txt.” https://developers.google.com/search/docs/crawling-indexing/robots/intro
7. W3C Web Accessibility Initiative. “Forms Tutorial.” https://www.w3.org/WAI/tutorials/forms/

Note: Replace example.com in robots.txt and sitemap.xml with the final published website domain before deployment. The contact forms use a mailto link because this front-end project has no server-side email service or database.
