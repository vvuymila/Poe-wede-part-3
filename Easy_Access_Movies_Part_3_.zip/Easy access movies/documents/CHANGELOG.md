# Easy Access Movies — Changelog

## Part 3 — Enhancing Functionality and SEO (2 November 2026)
- Added movie search by title and sorting from A to Z / Z to A.
- Added interactive five-point rating selectors with visible feedback.
- Added expandable FAQ sections using HTML details and summary elements.
- Added a poster gallery with a larger lightbox view; close with the Close button, outside click, or Escape.
- Added a dedicated enquiry form with required fields, email and phone validation, character limits, and enquiry categories.
- Added a separate contact form for general messages and feedback.
- Added JavaScript client-side validation and accessible status messages.
- Added SEO page descriptions, keywords, author/robots metadata, descriptive headings and image alt text.
- Added robots.txt and sitemap.xml templates.
- Improved mobile layout, focus outlines, form contrast, and responsive gallery styling.
- Updated README and references.

## Feedback / corrections from Part 2
- Retained the existing Easy Access Movies name, poster files, trailer files, navigation style and plain HTML/CSS approach.
- Corrected heading and form text contrast for the dark background.
- Kept the website lightweight and did not add a database or framework.
