/* Easy Access Movies - Part 3 JavaScript enhancements */
document.addEventListener("DOMContentLoaded", () => {
  const grid = document.querySelector("#movieGrid");
  const search = document.querySelector("#movieSearch");
  const sort = document.querySelector("#movieSort");
  const status = document.querySelector("#searchStatus");

  if (grid && search && sort) {
    const cards = Array.from(grid.querySelectorAll(".movie-card"));
    const originalOrder = new Map(cards.map((card, index) => [card, index]));
    function updateMovies() {
      const query = search.value.trim().toLowerCase();
      const visibleCards = cards.filter(card =>
        card.querySelector("h3").textContent.toLowerCase().includes(query)
      );
      visibleCards.sort((a, b) => {
        if (sort.value === "az") return a.querySelector("h3").textContent.localeCompare(b.querySelector("h3").textContent);
        if (sort.value === "za") return b.querySelector("h3").textContent.localeCompare(a.querySelector("h3").textContent);
        return originalOrder.get(a) - originalOrder.get(b);
      });
      cards.forEach(card => { card.hidden = !visibleCards.includes(card); });
      visibleCards.forEach(card => grid.appendChild(card));
      status.textContent = visibleCards.length + (visibleCards.length === 1 ? " movie found." : " movies found.");
      let empty = document.querySelector("#noMovies");
      if (visibleCards.length === 0) {
        if (!empty) {
          empty = document.createElement("p");
          empty.id = "noMovies";
          empty.className = "empty-state";
          empty.textContent = "No movies match your search. Try another title.";
          grid.after(empty);
        }
      } else if (empty) empty.remove();
    }
    search.addEventListener("input", updateMovies);
    sort.addEventListener("change", updateMovies);
    updateMovies();
  }

  document.querySelectorAll(".movie-rating").forEach(select => {
    select.addEventListener("change", () => {
      const feedback = select.parentElement.querySelector(".rating-feedback");
      feedback.textContent = select.value ? "Thank you! You selected " + select.value + " out of 5." : "";
    });
  });

  const lightbox = document.querySelector("#lightbox");
  const lightboxImage = document.querySelector("#lightboxImage");
  const closeLightbox = document.querySelector("#closeLightbox");
  document.querySelectorAll(".gallery-image").forEach(button => {
    button.addEventListener("click", () => {
      const image = button.querySelector("img");
      lightboxImage.src = image.src;
      lightboxImage.alt = image.alt;
      lightbox.hidden = false;
      closeLightbox.focus();
    });
  });
  function closeGallery() {
    if (lightbox) lightbox.hidden = true;
  }
  if (closeLightbox) closeLightbox.addEventListener("click", closeGallery);
  if (lightbox) lightbox.addEventListener("click", event => { if (event.target === lightbox) closeGallery(); });
  document.addEventListener("keydown", event => { if (event.key === "Escape") closeGallery(); });

  document.querySelectorAll("form[data-validate]").forEach(form => {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const message = form.querySelector(".form-message");
      if (!form.checkValidity()) {
        form.reportValidity();
        message.textContent = "Please check the highlighted fields and try again.";
        message.className = "form-message error";
        return;
      }
      const data = new FormData(form);
      const subject = encodeURIComponent(form.dataset.emailSubject || "Easy Access Movies website message");
      const body = encodeURIComponent(Array.from(data.entries()).map(([key, value]) => key + ": " + value).join("\n"));
      message.textContent = "Your details passed validation. Your email application will open so you can send the message.";
      message.className = "form-message success";
      window.location.href = "mailto:ST10515213@rcconnect.edu.za?subject=" + subject + "&body=" + body;
    });
  });
});
